﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

// Importar static
using static APIRickAndMorty.APIControllers;
using static APIRickAndMorty.Models;
using static APIRickAndMorty.Views;

namespace APIRickAndMorty
{
    internal class Helpers
    {
        // Utilidades (Helpers)
        public static string ApiName() => "Rick & Morty";

        public static int? ValidateInput(string input)
        {
            if (!int.TryParse(input, out int opc) || (opc < 0 || opc > 9))
            {
                PrintInvalidOption();
                PrintWaitForPressKey();
                return null;
            }
            return opc;
        }
        // Valida que la entrada sea un número entero; si no lo es, devuelve null
        public static int ValidateIsNumberId(string input)
        {
            if (!int.TryParse(input, out int num))
            {
                Console.WriteLine("El valor ingresado no es valido");
                return -1;
            }
            return num;
        }

        public static string ReadInput() => Console.ReadLine();

        public static string ReadInputUpper() => Console.ReadLine().Trim().ToUpper();

        // Pide confirmación al usuario y, si acepta, agrega el elemento
        // a la lista de favoritos usando el ID y el objeto JSON ya deserializado.
        public static bool ConfirmOperationFavoriteList(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return false;
            return input.Trim().ToUpper() == "S";
        }

        public static async Task<List<ClassCharacter>> GetAllPagesList()
        {
            List<ClassCharacter> all = new List<ClassCharacter>();
            string url = GetUrl();

            while (url != null)
            {
                HttpResponseMessage response = await GetHttpRequest(url);
                if (!ValidatedHttpResponse(response)) break;

                string json = await GetJson(response);
                ClassRoot data = DeserializedJsonRoot(json);

                all.AddRange(data.ResultsList);

                url = data.Info.Next;
            }

            return all;
        }
        public static void PaginateListApi<T>(List<T> list, Action<T> PrintJson, int pageSize)
        {
            if (list == null || list.Count == 0)
            {
                PrintNoData();
                PrintWaitForPressKey();
                return;
            }

            int currentPage = 0;
            int totalPages = (int)Math.Ceiling(list.Count / (double)pageSize);

            while (true)
            {
                Console.Clear();
                PrintCountPagesAll(currentPage + 1, totalPages);

                var page = list
                    .Skip(currentPage * pageSize)
                    .Take(pageSize)
                    .ToList();

                foreach (var item in page)
                {
                    PrintJson(item);
                    PrintOnlyLane();
                }

                PrintSelectOption();
                string key = Console.ReadKey(true).Key.ToString().ToUpper();

                if (key == "N" && currentPage < totalPages - 1)
                    currentPage++;
                else if (key == "B" && currentPage > 0)
                    currentPage--;
                else if (key == "Q")
                    break;
            }
        }
    }
}
