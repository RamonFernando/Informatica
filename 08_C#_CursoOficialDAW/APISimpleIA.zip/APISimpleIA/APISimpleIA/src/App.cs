
using static APISimpleIA.APIBuscarDigimon;
using static APISimpleIA.APIListarGuardados;


namespace APISimpleIA
{
    public static class App
    {
        public static string BASE_URL = "https://digimon-api.vercel.app/api/digimon";

        public static async Task Run()
        {
            while (true)
            {
                Console.WriteLine("\n=== MENU DIGIMON ===");
                Console.WriteLine("1. Buscar Digimon");
                Console.WriteLine("2. Mostrar guardados");
                Console.WriteLine("0. Salir");
                Console.Write("Opción: ");

                string? input = Console.ReadLine();

                if (!int.TryParse(input, out int opcion))
                {
                    Console.WriteLine("Entrada no válida");
                    Console.ReadKey();
                    continue;
                }

                switch (opcion)
                {
                    case 1:
                        await BuscarDigimon();
                        break;

                    case 2:
                        ListarGuardados();
                        break;

                    case 0:
                        Console.WriteLine("Saliendo...");
                        Environment.Exit(0);
                        break;

                    default:
                        Console.WriteLine("Opción inválida.\n");
                        break;
                }
            }
        }
    }
}
