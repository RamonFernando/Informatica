
using static APISimpleIA.APIGetDigimonAsync;
using static APISimpleIA.Services;


namespace APISimpleIA
{
    public static class APIBuscarDigimon
    {
        public static async Task BuscarDigimon()
        {
            Console.Write("Escribe el nombre del Digimon: ");
            string? name = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(name))
            {
                Console.WriteLine("Entrada no valida.\n");
                Console.ReadKey();
                return;
            }
            
            // Buscamos el Digimon en la API
            var json = await GetDigimonAsync(name);

            if (json == null)
            {
                Console.WriteLine("Digimon no encontrado.\n");
                Console.ReadKey();
                return;
            }

            var root = json.RootElement[0];

            // string digimonName = root.GetProperty("name").GetString()!;
            // string level = root.GetProperty("levels")[0].GetProperty("level").GetString()!;
            

            // Validar que el Digimon tenga los campos requeridos
            string digimonName = root.GetProperty("name").GetString()!;
            string level = root.TryGetProperty("level", out var levelProp)
                ? levelProp.GetString() ?? "unknown"
                : "unknown";
            
            // Mostramos y pedimos confirmacion para guardar
            Console.WriteLine($"\nNombre: {digimonName}");
            Console.WriteLine($"Nivel: {level}");
            

            Console.Write("\n¿Quieres guardarlo? (s/n): ");
            string? respuesta = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(respuesta))
            {
                Console.WriteLine("Respuesta no valida.\n");
                Console.ReadKey();
                return;
            }
            respuesta = respuesta.Trim().ToLower();

            // Comprobamos que no exista y agregamos a la lista
            if (respuesta == "s")
            {
                if (MisDigimons.Any(d => d.Name == digimonName))
                {
                    Console.WriteLine($"El Digimon  {digimonName} ya esta guardado.\n");
                    Console.ReadKey();
                    return;
                }
                MisDigimons.Add(new Digimon
                {
                    Name = digimonName,
                    Level = level,
                });

                Console.WriteLine("Guardado.\n");
                Console.ReadKey();
            }
        }
    }
}
